package hierarquia;

public class consumidor {

	public static void main(String[] args) {
		/*
		funcionario novo;
		novo = new funcionario(
		"123456",
		"joao da silva",
		"joao@gmail.com",
		"413562-4545",
		"1990-08-12"
		);
		*/
		/*
		terceiro novo1;
		novo1 = new terceiro(
		"6987456",
		"marcos da silva",
		"marcos@gmail.com",
		"413666-4545",
		"1999-12-12"
		);
		
		//System.out.println(novo.save());
		System.out.println(novo1.find());*/
		
		/*
		gerente novo;
		novo = new gerente();
		//novo.save("123456", 222, 10);
		
		novo.cpf = "123456";
		System.out.println(novo.calculabonus());
		*/
		/*
		terceiro noivo;
		noivo = new terceiro();
		noivo.cpf = "123456";
		
		System.out.println(noivo.encerrar_contrato());
		*/
		
	}
}


